﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressingForWeather.Class
{
    public class TemperatureCondition
    {
        private string _temperatureType;
      
        List<int> _exclusionCommandIdList = new List<int>();

        public string TemperatureType
        {
            get { return _temperatureType; }
            set { _temperatureType = value; }
        }

        public List<int> ExclusionCommandList
        {
            get { return  _exclusionCommandIdList; }
            set {  _exclusionCommandIdList = value; }
        }
       
        public TemperatureCondition()
        {

        }

        public TemperatureCondition(string weatherType)
        {
            _temperatureType = weatherType;
          
        }
    }
}
