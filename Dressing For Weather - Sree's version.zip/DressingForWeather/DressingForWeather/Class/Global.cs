﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressingForWeather.Class
{
    public class Global
    {
        private const string CLASSNAME = "Global";
        private List<Class.Command> _listCommand = new List<Class.Command>();
        private List<int> _userEnteredCommands =  new List<int>();
        private List<TemperatureCondition> _listWeatherCondition = new List<TemperatureCondition>();
        private TemperatureCondition _enteredTemperatureCondition;
        private string _temperatureCondition;
        private string _userResponse;

        public List<Class.Command> CommandList
        {
            get { return _listCommand; }
            set { _listCommand = value; }
        }

        public List<int> UserEnteredCommands
        {
            get { return _userEnteredCommands; }
            set { _userEnteredCommands = value; }
        }

        public List<Class.TemperatureCondition> WeatherConditionList
        {
            get { return _listWeatherCondition; }
            set { _listWeatherCondition = value; }
        }

        public TemperatureCondition  EnteredTemperatureCondition
        {
            get { return _enteredTemperatureCondition; }
            set { _enteredTemperatureCondition = value; }
        }

        public string TemperatureCondition
        {
            get { return _temperatureCondition; }
            set { _temperatureCondition = value; }
        }

        public string UserResponse
        {
            get { return _userResponse; }
            set { _userResponse = value; }
        }

        /// <summary>
        /// Populate a list with all the commands for the rules.
        /// </summary>
        public void PopulateCommands()
        {
            const string MODNAME = "PopulateCommands";
            try
            {
                Command objCommand = new Command();
                objCommand.commandId = 1;
                objCommand.CommandDescription = "Put on Sandals";
                objCommand.ColdResponse = "boots";
                objCommand.HotResponse = "sandals";
                objCommand.BeforeCommandId.Add(3);
                objCommand.BeforeCommandId.Add(6);
                CommandList.Add(objCommand);

                Command objCommand2 = new Command();
                objCommand2.commandId = 2;
                objCommand2.CommandDescription = "Put on headwear";
                objCommand2.HotResponse = "sun visor";
                objCommand2.ColdResponse = "hat";
                objCommand2.BeforeCommandId.Add(4);
                CommandList.Add(objCommand2);

                Command objCommand3 = new Command();
                objCommand3.commandId = 3;
                objCommand3.CommandDescription = "Put on socks";
                objCommand3.HotResponse = "fail";
                objCommand3.ColdResponse = "socks";
                CommandList.Add(objCommand3);

                Command objCommand4 = new Command();
                objCommand4.commandId = 4;
                objCommand4.CommandDescription = "Put on shirt";
                objCommand4.HotResponse = "t-shirt";
                objCommand4.ColdResponse = "shirt";
                CommandList.Add(objCommand4);

                Command objCommand5 = new Command();
                objCommand5.commandId = 5;
                objCommand5.CommandDescription = "Put on jacket";
                objCommand5.ColdResponse = "jacket";
                objCommand5.HotResponse = "fail";
                objCommand5.BeforeCommandId.Add(4);
                CommandList.Add(objCommand5);

                Command objCommand6 = new Command();
                objCommand6.commandId = 6;
                objCommand6.CommandDescription = "Put on pants";
                objCommand6.ColdResponse = "pants";
                objCommand6.HotResponse = "shorts";
                CommandList.Add(objCommand6);

                Command objCommand7 = new Command();
                objCommand7.commandId = 7;
                objCommand7.CommandDescription = "Leave house";
                objCommand7.ColdResponse = "leaving house";
                objCommand7.HotResponse = "leaving house";
                CommandList.Add(objCommand7);

                Command objCommand8 = new Command();
                objCommand8.commandId = 8;
                objCommand8.CommandDescription = "Take off pajamas";
                objCommand8.ColdResponse = "Removing PJs";
                objCommand8.HotResponse = "Removing PJs";
                CommandList.Add(objCommand8);
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }       

        }


        public void PopulateWeatherCondition()
        {
            const string MODNAME = "PopulateWeatherCondition";
            try
            {
                TemperatureCondition objWeatherCondition = new TemperatureCondition();
                objWeatherCondition.TemperatureType = "COLD";
                WeatherConditionList.Add(objWeatherCondition);

                TemperatureCondition objWeatherCondition1 = new TemperatureCondition();
                objWeatherCondition1.TemperatureType = "HOT";
                objWeatherCondition1.ExclusionCommandList = new List<int>();
                objWeatherCondition1.ExclusionCommandList.Add(3);
                objWeatherCondition1.ExclusionCommandList.Add(5);
                WeatherConditionList.Add(objWeatherCondition1);
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
        }


#region "Subs"

        public void Clear()
        {
            const string MODNAME = "Clear";
            try
            {
                UserEnteredCommands.Clear();
                TemperatureCondition = string.Empty;
                UserResponse = string.Empty;
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
        }

        /// <summary>
        /// Get all the user entered actions from the screen.
        /// </summary>
        public void GetEnteredCommands(string enteredCommands)
        {
            const string MODNAME = "GetEnteredCommands";
            Char delimiter = ',';
            int count = 0;
            bool isNumeric;
            int command;
            string[] commands = enteredCommands.Split(delimiter);
            try
            {
                foreach (string s in commands)
                {
                    if (s.Trim() != "")
                    {
                        if (count == 0 && s.Trim().Length > 4) //some more UI checking is needed.
                        {
                            string[] commands1 = s.Trim().Split();
                            TemperatureCondition = commands1[0];
                            foreach (string s1 in commands1)
                            {
                                isNumeric = int.TryParse(s1, out command);
                                if (isNumeric)
                                    UserEnteredCommands.Add(Convert.ToInt16(command));
                            }
                        }
                        else
                        {
                            isNumeric = int.TryParse(s, out command);
                            if (isNumeric)
                                UserEnteredCommands.Add(Convert.ToInt16(command));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
        }


        /// <summary>
        /// Validate the entered commands to see whether they are following the rules, and output the result if validation passed.
        /// </summary>
        public Boolean ValidateCommands()
        {
            const string MODNAME = "ValidateCommands";
            Boolean isValid;

            try
            { 
                //Get the temperature condition entered by the user
                isValid = CheckWeatherCondition();

                //check whether the command id 8 is the first action
                if (isValid)
                    isValid = FirstAction(); 

                //check whether all commands are entered
                if (isValid)
                    isValid = ChkAllCommands();

                //Check whether any comment is repeated, also look for any invalid comments
                if (isValid)
                    isValid = ChkRepeatAndInValidAndFailedCommand();

                //Check whehther the before and after commands are entered
                if (isValid)
                    isValid = ChkBeforeAndAfterCommands();

              

                return isValid;
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
                return false;
            }           
        }



        /// <summary>
        /// Check to see whether the user entered weather condition is a valid weather condition for the app.
        /// </summary>
        /// <returns></returns>
        public Boolean CheckWeatherCondition()
        {
            const string MODNAME = "CheckWeatherCondition";
            try
            {
                foreach (Class.TemperatureCondition objTemperatureCondition in WeatherConditionList )
                {
                    if (objTemperatureCondition.TemperatureType == TemperatureCondition.Trim().ToUpper())
                    {
                        EnteredTemperatureCondition = objTemperatureCondition;
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
            return false;
        }

        /// <summary>
        /// Check for the first action 
        /// </summary>
        /// <returns></returns>
        public Boolean FirstAction()
        {
            const string MODNAME = "FirstAction";
            try
            {                
                for (int cnt = 0; cnt <= UserEnteredCommands.Count - 1; cnt++)
                {
                    if (cnt == 0 && UserEnteredCommands[cnt] == 8)
                        return true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
            return false;
        }

        /// <summary>
        /// Checking to see for any repeated command eg:- HOT 8,7,6,6
        /// Also checking for an invalid command eg:- HOT 8,7,6,12 , in this case command id 12 didn't exist.
        /// </summary>
        /// <returns></returns>
        public Boolean ChkRepeatAndInValidAndFailedCommand()
        {            
            const string MODNAME = "ChkRepeatAndInValidAndFailedCommand";

            Class.Command objEnteredCommand;
            try
            {
                for (int i = 0; i <= UserEnteredCommands.Count - 1; i++)
                {
                    //check entered command is a valid command.
                    objEnteredCommand = CommandList.Find(x => x.commandId == UserEnteredCommands[i]);
                    if (objEnteredCommand == null) return false;

                    //check for repeat entry of a command. 
                    for (int j = i + 1; j <= UserEnteredCommands.Count-1; j++)
                    {                        
                        if (UserEnteredCommands[i] == UserEnteredCommands[j])
                            return false;
                    }

                    //Check whether the action is a failed command for the weather
                    if ((TemperatureCondition.Trim().ToUpper() == "COLD" && objEnteredCommand.ColdResponse.Trim().ToUpper() == "FAIL")
                           || (TemperatureCondition.Trim().ToUpper() == "HOT" && objEnteredCommand.HotResponse.Trim().ToUpper() == "FAIL"))
                            return false;        
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
            return true;
        }

        public Boolean ChkBeforeAndAfterCommands()
        {
            Class.Command objEnteredCommand;
            int  beforeCommand;            
            Boolean beforeCommandExists = false;
            const string MODNAME = "ChkBeforeAndAfterCommands";
            try
            {
                for (int j = 0; j <= UserEnteredCommands.Count - 1; j++)
                {
                    objEnteredCommand = CommandList.Find(x => x.commandId == UserEnteredCommands[j]);

                    if (EnteredTemperatureCondition.TemperatureType.ToUpper().Trim() == "HOT")
                    {
                        if (j > 0)
                            UserResponse = UserResponse + ", " + objEnteredCommand.HotResponse;
                        else
                            UserResponse = objEnteredCommand.HotResponse;
                    }

                    if (EnteredTemperatureCondition.TemperatureType.ToUpper().Trim() == "COLD")
                    {
                        if (j > 0)
                            UserResponse = UserResponse + ", " + objEnteredCommand.ColdResponse;
                        else
                            UserResponse = objEnteredCommand.ColdResponse;
                    }


                    if (objEnteredCommand.AfterCommandId != null)
                    {
                        //before command checking.
                        if (objEnteredCommand.BeforeCommandId != null)
                        {
                            if (objEnteredCommand.BeforeCommandId.Count > 0)
                            {
                                for (int k = 0; k <= objEnteredCommand.BeforeCommandId.Count - 1; k++)
                                {
                                    beforeCommand = objEnteredCommand.BeforeCommandId[k];
                                    if (!(EnteredTemperatureCondition.ExclusionCommandList.Contains(beforeCommand)))
                                    {
                                        if (UserEnteredCommands.Contains(beforeCommand))
                                        {
                                            if (UserEnteredCommands.IndexOf(objEnteredCommand.BeforeCommandId[k]) < j)
                                                beforeCommandExists = true;
                                            else return false;
                                        }
                                    }
                                    else beforeCommandExists = true;
                                }
                            }
                        } //end of before command checking.

                    }
                }

              
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
           
            if (beforeCommandExists)
                    return true;
             else return false;
        }


        public Boolean ChkAllCommands()
        {
            const string MODNAME = "ChkAllCommands";
            try
            {
                foreach (Class.Command objCommand in CommandList)
                {
                    if (!(EnteredTemperatureCondition.ExclusionCommandList.Contains(objCommand.commandId)))
                    {
                        if (!(UserEnteredCommands.Contains(objCommand.commandId)))
                            return false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
            return true;
        }


        #endregion

    }
}
