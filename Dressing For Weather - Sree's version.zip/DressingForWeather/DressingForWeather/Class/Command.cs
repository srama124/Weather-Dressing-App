﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressingForWeather.Class
{
    public class Command
    {
        private int _commandId;
        private string _commandDescription;
        private string _hotResponse;
        private string _coldResponse;
        private List<int> _beforeCommandId = new List<int>();
        private List<int> _afterCommandId = new List<int>();
        private const string CLASSNAME = "Command";

        public int commandId
        {
            get { return _commandId; }
            set { _commandId = value; }
        }

        public string CommandDescription
        {
            get { return _commandDescription; }
            set { _commandDescription = value; }
        }

        public string HotResponse
        {
            get { return _hotResponse; }
            set { _hotResponse= value; }
        }

         public string ColdResponse
        {
            get { return _coldResponse; }
            set { _coldResponse = value; }
        }

         public List<int> BeforeCommandId
         {
             get { return _beforeCommandId; }
             set { _beforeCommandId = value; }
         }

         public List<int> AfterCommandId
         {
             get { return _afterCommandId; }
             set { _afterCommandId = value; }
         }

        public Command()
         { }

        public Command(int commandId, string commandDescription, string hotResponse, string coldResponse, List<int> beforeCommandId, List<int> afterCommandId)
        {
            _commandId = commandId;       
            _commandDescription = commandDescription;
            _hotResponse = hotResponse;
            _coldResponse = coldResponse;
            _beforeCommandId = beforeCommandId;
            _afterCommandId = afterCommandId;
        }
      
    }

}
