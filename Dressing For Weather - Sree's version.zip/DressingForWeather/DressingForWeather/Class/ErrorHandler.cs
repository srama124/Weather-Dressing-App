﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DressingForWeather.Class
{
    public class ErrorHandler
    {

        public static void LogError(string _className, string _methodName, string _message, Exception _ex, object _object)
        {
            StringBuilder _errorMsg = new StringBuilder();
            _errorMsg.AppendFormat("An unexpected error has occurred.{0}" +
                                   "If this error occurs frequently, please contact Dressing for Weather support team and provide the following details:{0}" +
                                   "Class: {1}{0}" +
                                   "Module: {2}{0}", Environment.NewLine, _className, _methodName);

            if (!string.IsNullOrEmpty(_message))
                _errorMsg.AppendFormat("Message: {0}{1}", _message, Environment.NewLine);

            if (_ex != null)
                _errorMsg.AppendFormat("Exception: {0}{1}", _ex.Message, Environment.NewLine);

#if DEBUG
            // Get stack trace for the exception with source file information
            if (_ex != null)
            {
                System.Diagnostics.StackTrace trace = new System.Diagnostics.StackTrace(_ex, true);
                StackFrame[] frames = trace.GetFrames();

                // Iterate over the frames extracting the information 
                foreach (StackFrame frame in frames)
                {
                    if (frame.GetFileLineNumber() != 0)
                        _errorMsg.AppendFormat("File Name {0} {4}  Method Name {1}( Line Number {2}, Column Number {3} {4})", frame.GetFileName(), frame.GetMethod().Name, frame.GetFileLineNumber(), frame.GetFileColumnNumber(), Environment.NewLine);
                }
            }

#endif
            System.Windows.Forms.MessageBox.Show(_errorMsg.ToString(), "DressingForWeather", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
           
        }

        public static void LogError(string _className, string _methodName, Exception _ex)
        {
            LogError(_className, _methodName, "", _ex);
        }

        public static void LogError(string _className, string _methodName, string _message)
        {
            LogError(_className, _methodName, _message, null);
        }

        public static void LogError(string _className, string _methodName, string _message, Exception _ex)
        {
            LogError(_className, _methodName, _message, _ex, null);
        }


    }
}    

