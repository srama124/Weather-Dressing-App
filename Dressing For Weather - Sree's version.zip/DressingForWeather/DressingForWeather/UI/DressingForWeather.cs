﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DressingForWeather
{
    public partial class frmWeather : Form
    {
        int sequenceCount = 0;
        private const string CLASSNAME = "frmWeather";
        Class.Global objGlobal = new Class.Global();

        public frmWeather()
        {
            InitializeComponent();
            objGlobal.PopulateCommands();
            objGlobal.PopulateWeatherCondition();           
        }
        
        #region "Event"

        private void txtEnteredCommand_KeyPress(object sender, KeyPressEventArgs e)
        {
            const string MODNAME = "txtEnteredCommand_KeyPress";
            try
            {
                if (e.KeyChar == ',')
                    sequenceCount++;
                else
                    sequenceCount = 0;

                //if ((!char.IsControl(e.KeyChar)  && !char.IsDigit(e.KeyChar)  && e.KeyChar != ',') 
                //    || sequenceCount > 1)
                if (sequenceCount > 1)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Class.ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }   
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Boolean isValid;
            const string MODNAME = "btnSubmit_Click";
            try
            {
                sequenceCount = 0;
                objGlobal.Clear();
                objGlobal.GetEnteredCommands(txtEnteredCommands.Text);
                isValid = objGlobal.ValidateCommands();
                if (!isValid)
                {
                    txtResult.ForeColor = Color.Red;
                    txtResult.Text = "fail";

                }
                else { txtResult.Text = objGlobal.UserResponse; }
            }
            catch (Exception ex)
            {
                Class.ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }
        }


     

        private void btnClear_Click(object sender, EventArgs e)
        {
            const string MODNAME = "btnClear_Click";
            try
            {                            
                txtEnteredCommands.Text = "";
                objGlobal.Clear();
                txtEnteredCommands.Focus();
                txtResult.Text = "";
            }
            catch (Exception ex)
            {
                Class.ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }   
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            const string MODNAME = "btnClose_Click";
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                Class.ErrorHandler.LogError(CLASSNAME, MODNAME, null, ex);
            }   
        }
   #endregion

    }
}
